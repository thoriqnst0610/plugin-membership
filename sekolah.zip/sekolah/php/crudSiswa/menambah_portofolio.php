<?php

require_once __DIR__ . '/../function.php';

function menambahPortofolio(string $id_mahasiswa)
{

    $id_portofolio = uuid();
    // Mengambil dan membersihkan data
    $deskripsi = isset($_POST['deskripsi']) ? sanitize_text_field($_POST['deskripsi']) : '';


        if (!empty($deskripsi) && isset($_FILES["photo"])) {
            
            try {

                $photo = gambarAlumni($_FILES["photo"]);

                if (is_wp_error($photo)) {
                    throw new Exception($photo->get_error_message());
                }

                $data = [
                    'id_portofolio' => $id_portofolio,
                    'id_mahasiswa' => $id_mahasiswa,
                    'photo' => $photo,
                    'keterangan' => $deskripsi
                ];

                $id_baru = tambahPortofolio('portofolio', $data);

                if (is_wp_error($id_baru)) {
                    throw new Exception("Error: " . $id_baru->get_error_message());
                } else {
                    return "Selamat Berhasil";
                }
            } catch (Exception $e) {

                return "ada kesalahan dalam file yang di upload, lakukan pendaftaran Lagi!" . addslashes($e->getMessage());
            }
        } else {

            return "data yang diinput tidak lengkap, lakukan pendaftaran Lagi!";
        }
}
