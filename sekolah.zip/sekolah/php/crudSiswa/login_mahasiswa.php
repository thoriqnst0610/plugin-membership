<?php

require_once __DIR__ . '/../function.php';

function loginMahasiswaLagi()
{

    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';


        if (!empty($username)) {

            try {

               
                $user =  loginMahasiswa('mahasiswa',$username, $password);
                if($user == null){
                    return false;
                }
                return $user->id_mahasiswa;
                
            } catch (Exception $e) {

                return "ada kesalahan" . addslashes($e->getMessage());
            }
        } else {

            return "data yang diinput tidak lengkap, lakukan pendaftaran Lagi!";
        }
}
