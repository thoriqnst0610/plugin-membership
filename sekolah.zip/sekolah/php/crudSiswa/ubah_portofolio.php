<?php
require_once __DIR__ . '/../function.php';

function mengubahPortofolio()
{
    $deskripsi = isset($_POST['deskripsi']) ? sanitize_text_field($_POST['deskripsi']) : '';
    $photo = isset($_POST['photo_post']) ? sanitize_text_field($_POST['photo_post']) : '';
    $id_portofolio = isset($_POST['id_portofolio']) ? sanitize_text_field($_POST['id_portofolio']) : '';
   
    try {
        if (!empty($deskripsi)) {

            if (isset($_FILES["photo"])) {
                if ($_FILES["photo"]["error"] === UPLOAD_ERR_OK) {
                    $photo = gambarAlumni($_FILES["photo"]);
                    if (is_wp_error($photo)) {
                        throw new Exception($photo->get_error_message());
                    }
                } 
            }

            // Pastikan photo_post hanya digunakan jika berhasil diupload
            $data = [
                'id_portofolio' => $id_portofolio,
                'photo' => $photo,
                'keterangan' => $deskripsi
            ];

            // Mulai-Ubah data
            $where = array('id_portofolio' => $id_portofolio);
            $ubahData = editPortofolio('portofolio', $data, $where);
            if ($ubahData) {
                return "Berhasil mengubah Portofolio";
            } else {
                return "Tidak ada perubahan";
            }
        } else {
            throw new Exception("Data input harus lengkap");
        }
    } catch (Exception $ex) {
        return "Ada kesalahan: " . $ex->getMessage();
    }
}