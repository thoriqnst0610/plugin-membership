<?php

function menghapusPortofolio(string $id_portofolio)
{

    $where = array('id_portofolio' => $id_portofolio);
    $hapusData = hapusPortofolio('portofolio', $where);
}

function menghapusPortofolio1(string $id_portofolio)
{

    $where = array('id_mahasiswa' => $id_portofolio);
    $hapusData = hapusPortofolio('portofolio', $where);
}