<?php

require_once __DIR__ . '/../function.php';

function loginUserLagi()
{

    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';


        if (!empty($username)) {

            try {

               
                $user =  loginUser('user',$username, $password);
                if($user == null){
                    return false;
                }
                return "berhasil Login";
                
            } catch (Exception $e) {

                return "ada kesalahan" . addslashes($e->getMessage());
            }
        } else {

            return "data yang diinput tidak lengkap, lakukan pendaftaran Lagi!";
        }
}
