<?php

require_once __DIR__ . '/../function.php';

function menambahMahasiswa()
{

    $id_mahasiswa = uuid();
    // Mengambil dan membersihkan data
    $nama_mahasiswa = isset($_POST['nama_mahasiswa']) ? sanitize_text_field($_POST['nama_mahasiswa']) : '';
    $alamat_mahasiswa = isset($_POST['alamat_mahasiswa']) ? sanitize_textarea_field($_POST['alamat_mahasiswa']) : ''; // Jika menggunakan textarea
    $telepon = isset($_POST['telepon']) ? sanitize_text_field($_POST['telepon']) : '';
    $email = isset($_POST['harga']) ? sanitize_text_field($_POST['harga']) : ''; // Gunakan sanitize_email untuk email
    $jenis_kelamin = isset($_POST['jenis_kelamin']) ? sanitize_text_field($_POST['jenis_kelamin']) : '';
    $kategori = isset($_POST['kategori']) ? sanitize_text_field($_POST['kategori']) : '';
    $bio = isset($_POST['bio']) ? sanitize_text_field($_POST['bio']) : '';
    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';
            try {

                $pasphoto = gambarAlumni($_FILES["pasphoto"]);

                if (is_wp_error($pasphoto)) {
                    throw new Exception($pasphoto->get_error_message());
                }

                $data = [
                    'id_mahasiswa' => $id_mahasiswa,
                    'nama_mahasiswa' => $nama_mahasiswa,
                    'alamat_mahasiswa' => $alamat_mahasiswa,
                    'telepon' => $telepon,
                    'email' => $email,
                    'jenis_kelamin' => $jenis_kelamin,
                    'pasphoto' => $pasphoto,
                    'kategori' => $kategori,
                    'bio' => $bio,
                    'username' => $username,
                    'password' => $password
                ];

                $cek_username = ambilMahasiswaUsername('mahasiswa',$username);
                if($cek_username == null){
                    $id_baru = tambahMahasiswa('mahasiswa', $data);
                }else{
                    
                    return false;
                }

                if (is_wp_error($id_baru)) {
                    throw new Exception("Error: " . $id_baru->get_error_message());
                } else {
                    return "Selamat Berhasil Melakukan Pendaftaran Haraf Login Sekarang";
                }
            } catch (Exception $e) {

                return "ada kesalahan dalam file yang di upload, lakukan pendaftaran Lagi!" . addslashes($e->getMessage());
            }
        }
