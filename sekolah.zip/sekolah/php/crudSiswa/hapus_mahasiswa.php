<?php

function menghapusMahasiswa(string $id_mahasiswa)
{

    $where = array('id_mahasiswa' => $id_mahasiswa);
    $hapusData = hapusMahasiswa('mahasiswa', $where);
}
