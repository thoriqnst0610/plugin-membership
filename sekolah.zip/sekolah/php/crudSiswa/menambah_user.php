<?php

require_once __DIR__ . '/../function.php';

function menambahUser()
{

    $id_user = uuid();
    // Mengambil dan membersihkan data
    $nama_user = isset($_POST['nama_user']) ? sanitize_text_field($_POST['nama_user']) : '';
    $alamat_user = isset($_POST['alamat']) ? sanitize_textarea_field($_POST['alamat']) : '';
    $telepon = isset($_POST['telepon']) ? sanitize_text_field($_POST['telepon']) : '';
    $jenis_kelamin = isset($_POST['jenis_kelamin']) ? sanitize_text_field($_POST['jenis_kelamin']) : '';
    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';


        if (!empty($nama_user) && !empty($alamat_user) && !empty($telepon)) {

            try {

                $data = [
                    'id_user' => $id_user,
                    'nama_user' => $nama_user,
                    'jenis_kelamin' => $jenis_kelamin,
                    'alamat' => $alamat_user,
                    'telepon' => $telepon,
                    'username' => $username,
                    'password' => $password
                ];

                $id_baru = tambahUser('user', $data);

                if (is_wp_error($id_baru)) {
                    throw new Exception("Error: " . $id_baru->get_error_message());
                } else {
                    return "Selamat Berhasil Melakukan Pendaftaran Haraf Login Sekarang";
                }
            } catch (Exception $e) {

                return "ada kesalahan" . addslashes($e->getMessage());
            }
        } else {

            return "data yang diinput tidak lengkap, lakukan pendaftaran Lagi!";
        }
}
