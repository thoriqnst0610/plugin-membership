<?php
require_once __DIR__ . '/../function.php';

function mengubahProfil(string $id_mahasiswa)
{
    $nama_mahasiswa = isset($_POST['nama_mahasiswa']) ? sanitize_text_field($_POST['nama_mahasiswa']) : '';
    $bio = isset($_POST['bio']) ? sanitize_textarea_field($_POST['bio']) : '';
    $email = isset($_POST['email']) ? sanitize_textarea_field($_POST['email']) : '';
    $pasphoto_post = isset($_POST['pasphoto_post']) ? sanitize_textarea_field($_POST['pasphoto_post']) : '';
   
    try {
        if (!empty($nama_mahasiswa) && !empty($bio) && !empty($email)) {

            if (isset($_FILES["pasphoto"])) {
                if ($_FILES["pasphoto"]["error"] === UPLOAD_ERR_OK) {
                    $pasphoto_post = gambarAlumni($_FILES["pasphoto"]);
                    if (is_wp_error($pasphoto_post)) {
                        throw new Exception($pasphoto_post->get_error_message());
                    }
                } 
            }

            // Pastikan pasphoto_post hanya digunakan jika berhasil diupload
            $data = array(
                'nama_mahasiswa' => $nama_mahasiswa,
                'email' => $email,
                'pasphoto' => $pasphoto_post,
                'bio' => $bio
            );



            // Mulai-Ubah data
            $where = array('id_mahasiswa' => $_SESSION['login_mahasiswa']);
            $ubahData = editProfil('mahasiswa', $data, $where);
            if ($ubahData) {
                return "Berhasil mengubah Profil";
            } else {
                return "Tidak ada perubahan";
            }
        } else {
            throw new Exception("Data input harus lengkap");
        }
    } catch (Exception $ex) {
        return "Ada kesalahan: " . $ex->getMessage();
    }
}
