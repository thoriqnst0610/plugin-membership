<?php

function uuid()
{
    $data = openssl_random_pseudo_bytes(16);
    assert(strlen($data) == 16);

    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

    return vsprintf('%s%s%s', str_split(bin2hex($data), 4));
}

// Fungsi untuk menangani upload file /../gambar_alumni/
function gambarAlumni($file)
{
    // Direktori tempat menyimpan file yang di-upload
    $uniq = uniqid();
    $targetDir = __DIR__ . "/../gambar_alumni/";
    $targetFile = $targetDir . $uniq . '-' . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Cek apakah file gambar adalah gambar sebenarnya
    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        return new WP_Error('not_image', "Maaf, file bukan gambar.");
    }

    // Cek format file
    if (!in_array($imageFileType, ['jpg', 'png', 'gif'])) {
        return new WP_Error('invalid_format', "Maaf, hanya format JPG, PNG, dan GIF yang diperbolehkan.");
    }

    // Cek ukuran file
    if ($file["size"] > 2000000) { // 1 MB = 1,000,000 bytes
        return new WP_Error('file_too_large', "Maaf, ukuran file terlalu besar. Maksimal 2 MB.");
    }

    // Cek apakah file dapat di-upload
    if (!move_uploaded_file($file["tmp_name"], $targetFile)) {
        return new WP_Error('upload_error', "Maaf, terjadi kesalahan saat meng-upload file.");
    }

    return $uniq . '-' . basename($file["name"]);
}


// Fungsi untuk menangani upload file
function pasPhoto($file)
{
    // Direktori tempat menyimpan file yang di-upload
    $uniq = uniqid();
    $targetDir = __DIR__ . "/pasphoto/";
    $targetFile = $targetDir . $uniq . '-' . basename($file["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Cek apakah file gambar adalah gambar sebenarnya
    $check = getimagesize($file["tmp_name"]);
    if ($check !== false) {
        //file gambar
    } else {
        return new WP_Error("maaf, File bukan gambar.");
        $uploadOk = 0;
    }

    // Cek format file
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "gif") {
        return new WP_Error("maaf, Hanya format JPG, PNG, dan GIF yang diperbolehkan.");
        $uploadOk = 0;
    }

    // Cek ukuran file
    if ($file["size"] > 2000000) { // 1 MB = 1,000,000 bytes
        return new WP_Error("maaf, Ukuran file terlalu besar. Maksimal 2 MB.");
        $uploadOk = 0;
    }

    // Cek apakah $uploadOk diset ke 0 oleh kesalahan
    if ($uploadOk == 0) {
        return new WP_Error("maaf, File tidak di-upload.");
    } else {
        if (move_uploaded_file($file["tmp_name"], $targetFile)) {
            //berhasil
        } else {
            return new WP_Error("maaf, Terjadi kesalahan saat meng-upload file.");
        }
    }

    return $uniq.'-'.basename($file["name"]);
}

?>