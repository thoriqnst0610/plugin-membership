<?php


//alumni

function tambahSiswa($nama_table, $data = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Cek apakah insert berhasil
    $inserted = $wpdb->insert($table_name, $data);
    
    if ($inserted === false) {
        return new WP_Error('insert_failed', 'Gagal menambahkan data mahasiswa.');
    }
    
    // Mengembalikan ID dari baris yang baru ditambahkan
    return $wpdb->insert_id;
}

function tambahUser($nama_table, $data = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Cek apakah insert berhasil
    $inserted = $wpdb->insert($table_name, $data);
    
    if ($inserted === false) {
        return new WP_Error('insert_failed', 'Gagal menambahkan data mahasiswa.');
    }
    
    // Mengembalikan ID dari baris yang baru ditambahkan
    return $wpdb->insert_id;
}

function tambahPortofolio($nama_table, $data = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Cek apakah insert berhasil
    $inserted = $wpdb->insert($table_name, $data);
    
    if ($inserted === false) {
        return new WP_Error('insert_failed', 'Gagal menambahkan data siswa.');
    }
    
    // Mengembalikan ID dari baris yang baru ditambahkan
    return $wpdb->insert_id;
}

function tambahMahasiswa($nama_table, $data = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Cek apakah insert berhasil
    $inserted = $wpdb->insert($table_name, $data);
    
    if ($inserted === false) {
        return new WP_Error('insert_failed', 'Gagal menambahkan data siswa.');
    }
    
    // Mengembalikan ID dari baris yang baru ditambahkan
    return $wpdb->insert_id;
}

function ambilPortofolioId($nama_table, $id_mahasiswa)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id_mahasiswa = %s", $id_mahasiswa);
    $query = $wpdb->get_results($sql);
    
    return $query;
}

function ambilMahasiswa($nama_table)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $sql = "SELECT * FROM " . $table_name;
    $query = $wpdb->get_results($sql);
    return $query;
}

function ambilMahasiswaId($nama_table, $id_mahasiswa)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id_mahasiswa = %s", $id_mahasiswa);
    $query = $wpdb->get_row($sql);
    
    return $query;
}

function ambilMahasiswaUsername($nama_table, $username)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE username = %s", $username);
    $query = $wpdb->get_row($sql);
    
    return $query;
}

function loginUser($nama_table, $username, $password)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Validasi input
    if (empty($username) || empty($password)) {
        return null; // atau bisa lempar error
    }

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE username = %s AND password = %s", $username, $password);
    $user = $wpdb->get_row($sql);

    return $user; // Akan mengembalikan data pengguna atau null jika tidak ditemukan
}

function loginMahasiswa($nama_table, $username, $password)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Validasi input
    if (empty($username) || empty($password)) {
        return null; // atau bisa lempar error
    }

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE username = %s AND password = %s", $username, $password);
    $user = $wpdb->get_row($sql);

    return $user; // Akan mengembalikan data pengguna atau null jika tidak ditemukan
}

function hapusPortofolio($nama_table, $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $delete = $wpdb->delete($table_name, $where);
    return $delete;
}

function editProfil($nama_table, $data = array(), $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $update = $wpdb->update($table_name, $data, $where);
    return $update;
}

function editPortofolio($nama_table, $data = array(), $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $update = $wpdb->update($table_name, $data, $where);
    return $update;
}

function hapusMahasiswa($nama_table, $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $delete = $wpdb->delete($table_name, $where);
    return $delete;
}
