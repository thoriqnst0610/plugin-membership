<?php

if (!session_id()) {
    session_start();
}

add_shortcode('pendaftaran', 'pendaftaran');
function pendaftaran()
{
    ob_start();

    if (isset($_GET['aksi'])) {

        if ($_GET['aksi'] == 'daftarmahasiswa') {

            include LANDINGSEKOLAH_DIR . 'pendaftaran.php';
        }
    } else {

        include LANDINGSEKOLAH_DIR . 'login_mahasiswa.php';
    }

    return ob_get_clean();
}


add_shortcode('pendaftaran_user', 'pendaftaran_user');
function pendaftaran_user()
{

    ob_start();
    if ($_SERVER['REQUEST_METHOD'] == "POST") {

        if ($_POST['aksi'] == 'loginuser') {

            require_once __DIR__ . '/crudSiswa/login_user.php';
            $pesan = loginUserLagi();

            if ($pesan == false) {

                $pesan = "username atau password salah";
                include LANDINGSEKOLAH_DIR . 'login_user.php';
            } else {

                $_SESSION['login_user'] = $pesan;
                include LANDINGSEKOLAH_DIR . 'login_user.php';
            }
        } else {

            require_once __DIR__ . '/crudSiswa/menambah_user.php';
            $pesan = menambahUser();
            include LANDINGSEKOLAH_DIR . 'login_user.php';
            exit();
        }
    }

    if (isset($_GET['aksi'])) {

        if ($_GET['aksi'] == 'daftaruser') {

            include LANDINGSEKOLAH_DIR . 'pendaftaran_user.php';
        }
    } else {

        include LANDINGSEKOLAH_DIR . 'login_user.php';
    }

    return ob_get_clean();
}

add_shortcode('crud', 'crud');
function crud()
{
    ob_start();

    if ($_SERVER['REQUEST_METHOD'] == "POST") {

        if (isset($_POST['editprofil'])) {

            require_once __DIR__ . '/crudSiswa/ubah_profil.php';

            $pesan = mengubahProfil($_SESSION['login_mahasiswa']);
        } else if(isset($_POST['id_portofolio'])){
            
            require_once __DIR__ . '/crudSiswa/ubah_portofolio.php';

            $pesan = mengubahPortofolio();

        }else {
            require_once __DIR__ . '/crudSiswa/menambah_portofolio.php';
            $pesan = menambahPortofolio($_SESSION['login_mahasiswa']);
        }

        include LANDINGSEKOLAH_DIR . 'tampil_portofolio.php';
    } else {

        if (isset($_GET['aksi'])) {

            if ($_GET['aksi'] == 'tambahportofolio') {

                include LANDINGSEKOLAH_DIR . 'tambah_portofolio.php';
            }
        } else {

            if (isset($_GET['id_portofolio'])) {

                require_once __DIR__ . '/crudSiswa/menghapus_portofolio.php';
                menghapusPortofolio($_GET['id_portofolio']);
            } else if (isset($_GET['logout'])) {
                unset($_SESSION['login_mahasiswa']);
            }

            include LANDINGSEKOLAH_DIR . 'tampil_portofolio.php';
        }
    }
    return ob_get_clean();
}

add_shortcode('daftar_freelance', 'daftar_freelance');
function daftar_freelance()
{
    ob_start();
    if (isset($_GET['id_mahasiswa'])) {

        include LANDINGSEKOLAH_DIR . 'menampilkan_portofolio.php';
    } else {
        include LANDINGSEKOLAH_DIR . 'menampilkan_freelance.php';
    }
    return ob_get_clean();
}


add_action('template_redirect', 'validasi');
function validasi()
{
    if (is_page('umkm')) {
        if (!isset($_SESSION['login_mahasiswa'])) {

            wp_redirect(home_url('/freelance'));
            exit;
        }
        if (isset($_GET['logout'])) {
            unset($_SESSION['login_mahasiswa']);
            wp_redirect(home_url('/freelance'));
            exit;
        } else if (isset($_GET['hapus'])) {
            require_once __DIR__ . '/crudSiswa/hapus_mahasiswa.php';
            require_once __DIR__ . '/crudSiswa/menghapus_portofolio.php';
            menghapusPortofolio1($_SESSION['login_mahasiswa']);

            menghapusMahasiswa($_SESSION['login_mahasiswa']);
            unset($_SESSION['login_mahasiswa']);
            wp_redirect(home_url('/freelance'));
            exit;
        }
    } else if (is_page('freelance')) {

        if (isset($_SESSION['login_mahasiswa'])) {

            wp_redirect(home_url('/umkm'));
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if (isset($_POST['aksi'])) {

                if ($_POST['aksi'] == 'loginmahasiswa') {

                    require_once __DIR__ . '/crudSiswa/login_mahasiswa.php';
                    $pesan = loginMahasiswaLagi();

                    if ($pesan == false) {

                        $pesan = "Username atau password salah";
                        wp_redirect(home_url('/freelance?pesan=username atau password salah'));
                        exit;
                    } else {

                        $_SESSION['login_mahasiswa'] = $pesan;
                        $pesan = "berhasil Login";
                        wp_redirect(home_url('/umkm'));
                        exit;
                    }
                }
                }else if(isset($_POST['daftardong'])){
                    require_once __DIR__ . '/crudSiswa/menambah_mahasiswa.php';
                    $pesan = menambahMahasiswa();
                    if($pesan == false){
                        wp_redirect(home_url('/freelance?aksi=daftarmahasiswa&&pesan=username sudah terdaftar harap daftar ulang'));
                        exit;
                    }else{


                        wp_redirect(home_url('/freelance?pesan=berhasil mendaftar, Login Sekarang'));
                        exit;

                    }
            }
        }
    } else if (is_page('user')) {

        if (isset($_SESSION['login_user'])) {

            wp_redirect(home_url('/portofolio'));
            exit;
        }
        if ($_POST['aksi'] == 'loginuser') {

            require_once __DIR__ . '/crudSiswa/login_user.php';
            $pesan = loginUserLagi();

            if ($pesan == false) {

                $pesan = "username atau password salah";
                include LANDINGSEKOLAH_DIR . 'login_user.php';
            } else {

                wp_redirect(home_url('/portofolio'));
                exit;
            }
        }
    } else if (is_page('portofolio')) {

        if (isset($_GET['id_mahasiswa'])) {

            if (!isset($_SESSION['login_mahasiswa'])) {

                wp_redirect(home_url('/freelance'));
                exit;
            }
        }
    }
}
