<?php

/**
 * Function menampilkan menu
 * Hook: admin_menu
 */

add_action('admin_menu', 'menusekolah');
function menusekolah()
{
  
}