<?php

if (!session_id()) {
    session_start();
}

add_shortcode('pendaftaran', 'pendaftaran');
function pendaftaran()
{
    ob_start();

    if (isset($_SESSION['login_mahasiswa'])) {
        if (isset($_SESSION['login_mahasiswa'])) {
            $url = 'crud/';
            if (!is_admin()) {
                wp_redirect($url);
                exit;
            }
            // include LANDINGSEKOLAH_DIR . 'tampil_portofolio.php';
            // exit;
        }
    } else {

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if (isset($_POST['aksi'])) {

                if ($_POST['aksi'] == 'loginmahasiswa') {

                    require_once __DIR__ . '/crudSiswa/login_mahasiswa.php';
                    $pesan = loginMahasiswaLagi();
                    $_SESSION['login_mahasiswa'] = $pesan;

                    if (isset($_SESSION['login_mahasiswa'])) {
                        $url = 'crud/';
                        if (!is_admin()) {
                            wp_redirect($url);
                            exit;
                        }
                        // include LANDINGSEKOLAH_DIR . 'tampil_portofolio.php';
                        // exit;
                    }
                }
            } else {

                require_once __DIR__ . '/crudSiswa/menambah_mahasiswa.php';

                $pesan = menambahMahasiswa();
                include LANDINGSEKOLAH_DIR . 'login_mahasiswa.php';
                exit;
            }
        } else {

            if (isset($_GET['aksi'])) {

                if ($_GET['aksi'] == 'daftarmahasiswa') {

                    include LANDINGSEKOLAH_DIR . 'pendaftaran.php';
                }
            } else {

                include LANDINGSEKOLAH_DIR . 'login_mahasiswa.php';
            }
        }
    }

    return ob_get_clean();
}


add_shortcode('pendaftaran_user', 'pendaftaran_user');
function pendaftaran_user()
{

    ob_start();
    if (isset($_SESSION['login_user'])) {
        // $url = 'portofolio/';
        // // if (!is_admin()) {
        // //     wp_redirect($url);
        // //     exit;
        // // }
        // include LANDINGSEKOLAH_DIR . 'menampilkan_freelance.php';
        // exit();
    } {
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if ($_POST['aksi'] == 'loginuser') {

                require_once __DIR__ . '/crudSiswa/login_user.php';
                $pesan = loginUserLagi();

                $_SESSION['login_user'] = $pesan;

                $url = 'portofolio/';
                if (!is_admin()) {
                    wp_redirect($url);
                    exit;
                }
                // include LANDINGSEKOLAH_DIR . 'menampilkan_freelance.php';
                // exit();
            } else {
                require_once __DIR__ . '/crudSiswa/menambah_user.php';
                // $pesan = menambahUser();
                include LANDINGSEKOLAH_DIR . 'login_user.php';
                exit();
            }
        }
    }

    if (isset($_GET['aksi'])) {

        if ($_GET['aksi'] == 'daftaruser') {

            include LANDINGSEKOLAH_DIR . 'pendaftaran_user.php';
        }
    } else {

        include LANDINGSEKOLAH_DIR . 'login_user.php';
    }

    return ob_get_clean();
}

add_shortcode('crud', 'crud');
function crud()
{

    ob_start();

    if (isset($_SESSION['login_mahasiswa'])) {


        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            include __DIR__ . '/crudSiswa/menambah_portofolio.php';
            $pesan = menambahPortofolio($_SESSION['login_mahasiswa']);
            include LANDINGSEKOLAH_DIR . 'tampil_portofolio.php';
        } else {

            if (isset($_GET['aksi'])) {

                if ($_GET['aksi'] == 'tambahportofolio') {

                    include LANDINGSEKOLAH_DIR . 'tambah_portofolio.php';
                }
            } else {

                if (isset($_GET['id_portofolio'])) {

                    require_once __DIR__ . '/crudSiswa/menghapus_portofolio.php';
                    menghapusPortofolio($_GET['id_portofolio']);
                }

                include LANDINGSEKOLAH_DIR . 'tampil_portofolio.php';
            }
        }
    } else {

        // if (!is_admin()) {
        //     wp_safe_redirect(home_url('pendaftaran/'));
        //     exit; 
        // }
    }
    return ob_get_clean();
}

add_shortcode('daftar-freelance', 'daftar_freelance');
function daftar_freelance()
{
    ob_start();

    if (isset($_SESSION['login_user'])) {

        if (isset($_GET['id_mahasiswa'])) {

            include LANDINGSEKOLAH_DIR . 'menampilkan_portofolio.php';
        } else {
            $url = 'portofolio/';
            if (!is_admin()) {
                wp_redirect($url);
                exit;
            }
        }
    } else {

        $url = 'user/';
        if (!is_admin()) {
            wp_redirect($url);
            exit;
        }
        // include LANDINGSEKOLAH_DIR . 'login_user.php';
    }
    return ob_get_clean();
}


add_action('template_redirect', 'test');
function test()
{
    if (!isset($_SESSION['login_mahasiswa'])) {
        if (is_page('crud')) {
            wp_redirect(home_url('/pendaftaran'));
            exit;
        }
    }
}
