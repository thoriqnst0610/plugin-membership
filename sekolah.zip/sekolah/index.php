<?php

/**
 * Plugin Name: WP Freelance
 * Description: WP Freelance Custom
 * Author: Thoriq Nst
 * Author URI: https://nastiweb.my.id
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

// Act on plugin activation
register_activation_hook(__FILE__, "activate_wp_sekolah");
function activate_wp_sekolah()
{
    init_db_user();
    init_db_mahasiswa();
    init_db_portofolio();
}

function init_db_user()
{

    global $table_prefix, $wpdb;
    $userTable = $table_prefix . 'user';

    // Create user Table if not exist
    if ($wpdb->get_var("show tables like '$userTable'") != $userTable) {
        // Query - Create Table
        $sql = "CREATE TABLE `$userTable` (";
        $sql .= " `id_user` varchar(35) NOT NULL, ";
        $sql .= " `nama_user` varchar(100) NOT NULL, ";
        $sql .= " `jenis_kelamin` varchar(100) NOT NULL, ";
        $sql .= " `alamat` varchar(255), ";
        $sql .= " `telepon` varchar(15), ";
        $sql .= " `username` varchar(255), ";
        $sql .= " `password` varchar(255), ";
        $sql .= " PRIMARY KEY (`id_user`) ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1;";

        // Include Upgrade Script
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        // Create Table
        dbDelta($sql);
    }

}

function init_db_mahasiswa()
{
    global $table_prefix, $wpdb;
    $mahasiswa = $table_prefix . 'mahasiswa';

    // Create Calon Siswa Table if not exist
    if ($wpdb->get_var("show tables like '$mahasiswa'") != $mahasiswa) {
        // Query - Create Table
        $sql = "CREATE TABLE `$mahasiswa` (";
        $sql .= " `id_mahasiswa` varchar(35) NOT NULL, ";
        $sql .= " `nama_mahasiswa` varchar(100) NOT NULL, ";
        $sql .= " `alamat_mahasiswa` varchar(255), ";
        $sql .= " `telepon` varchar(15), ";
        $sql .= " `email` varchar(100), ";
        $sql .= " `jenis_kelamin` varchar(10), ";
        $sql .= " `pasphoto` varchar(255), ";
        $sql .= " `kategori` varchar(255), ";
        $sql .= " `bio` varchar(255), ";
        $sql .= " `username` varchar(255), ";
        $sql .= " `password` varchar(255), ";
        $sql .= " PRIMARY KEY (`id_mahasiswa`) ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1;";

        // Include Upgrade Script
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        // Create Table
        dbDelta($sql);
    }
}

function init_db_portofolio()
{
    global $table_prefix, $wpdb;
    $userTable = $table_prefix . 'portofolio';

    // Create user Table if not exist
    if ($wpdb->get_var("show tables like '$userTable'") != $userTable) {
        // Query - Create Table
        $sql = "CREATE TABLE `$userTable` (";
        $sql .= " `id_portofolio` varchar(35) NOT NULL, ";
        $sql .= " `id_mahasiswa` varchar(35) NOT NULL, ";
        $sql .= " `photo` varchar(255), ";
        $sql .= " `keterangan` text, ";
        $sql .= " PRIMARY KEY (`id_portofolio`), ";
        $sql .= " CONSTRAINT `fk_mahasiswa` FOREIGN KEY (`id_mahasiswa`) REFERENCES `" . $table_prefix . "mahasiswa`(`id_mahasiswa`) ON DELETE CASCADE ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1;";

        // Include Upgrade Script
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        // Create Table
        dbDelta($sql);
    }
}


// Act on plugin de-activation
register_deactivation_hook(__FILE__, "deactivate_wp_sekolah");
function deactivate_wp_sekolah()
{
    init_db_user();
    init_db_mahasiswa();
    init_db_portofolio();
}

function delete_db_user()
{
    global $table_prefix, $wpdb;
    $customerTable = $table_prefix . 'user_siswa';

    // Query - Delete Table
    $sql = "DROP TABLE IF EXISTS `$customerTable` ;";
    // Delete Table
    $wpdb->query($sql);
}

function delete_db_calon()
{
    global $table_prefix, $wpdb;
    $customerTable = $table_prefix . 'calon_siswa';

    // Query - Delete Table
    $sql = "DROP TABLE IF EXISTS `$customerTable` ;";
    // Delete Table
    $wpdb->query($sql);
}

function delete_db_pengaturan()
{
    global $table_prefix, $wpdb;
    $customerTable = $table_prefix . 'pengaturan';

    // Query - Delete Table
    $sql = "DROP TABLE IF EXISTS `$customerTable` ;";
    // Delete Table
    $wpdb->query($sql);
}


define('LANDINGSEKOLAH_DIR', plugin_dir_path(__FILE__) . '/views/landing/');
include 'php/model.php';
include 'php/admin.php';
include 'php/landing.php';


// Hook untuk menyambungkan CSS dan JS di Frontend
add_action('wp_enqueue_scripts', 'landingsekolah_script');
function landingsekolah_script() {
    wp_enqueue_style('bs_css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css');
    wp_enqueue_style('dt_css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
    wp_enqueue_style('dt_button_css', 'https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css');
    wp_enqueue_style('custom_css', plugins_url('/css/custom-min.css', __FILE__));

    // Menonaktifkan skrip jQuery default WordPress
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.7.0.js', array(), null, true);
    
    wp_enqueue_script('bs_js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js', array(), null, true);
    wp_enqueue_script('fa_js', 'https://kit.fontawesome.com/c00efe6860.js', array(), null, true);
    wp_enqueue_script('dt_js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_button_js', 'https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_zip_js', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js', array(), null, true);
    wp_enqueue_script('dt_pdf_js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', array(), null, true);
    wp_enqueue_script('dt_pdf_font_js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', array(), null, true);
    wp_enqueue_script('dt_button_html_js', 'https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_print_js', 'https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js', array('jquery'), null, true);

    wp_enqueue_script('custom_js', plugins_url('/js/custom-min.js', __FILE__), array(), null, true);
}
