<div class="container-fluid pt-3">
    <div class="d-flex align-items-center justify-content-between border-bottom border-dark mb-3 pb-1">
        <h3>Dashboard</h3>
        <div class="ml-auto">
            <a href="https://digiumkm.com/umkm//?logout=true" class="btn btn-danger text-decoration-none">Logout</a>
        </div>
    </div>

    <div class="container">
    <!-- Nav tabs -->
    <ul class="nav nav-tabs flex-nowrap" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link text-decoration-none active" id="portofolio-tab" data-toggle="tab" href="#portofolio" role="tab" aria-controls="portofolio" aria-selected="true">Manajemen Portofolio</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-decoration-none" id="profil-tab" data-toggle="tab" href="#profil" role="tab" aria-controls="profil" aria-selected="false">Manajemen Profil</a>
        </li>
    </ul>
</div>


    <!-- Tab content -->
    <div class="tab-content" id="myTabContent">
        <!-- Tab Portofolio -->
        <div class="tab-pane fade show active" id="portofolio" role="tabpanel" aria-labelledby="portofolio-tab">
            <div class="d-flex align-items-center justify-content-between mb-3 pb-1">
                <button data-toggle="modal" data-target="#tambahModal" class="btn btn-primary">Tambah</button>
            </div>

            <!-- Modal Form Tambah -->
            <div class="modal fade" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahModalLabel">Tambah Data Portofolio</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Deskripsi</label>
                                    <input class="col-9 form-control" type="text" name="deskripsi" placeholder="Ubah Deskripsi">
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">File Photo</label>
                                    <input class="col-9 form-control" type="file" name="photo" placeholder="Pilih Photo">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Notifikasi -->
            <?php if (isset($notifikasi)) { ?>
                <div class="bg bg-warning text-black p-3 mb-3 rounded text-center"><?php echo $notifikasi; ?></div>
            <?php } ?>

            <!-- Tabel tampil data -->
            <table class="table" id="alumni">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>No.</th>
                        <th>Deskripsi</th>
                        <th>Gambar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $ambilPortofolioId = ambilPortofolioId('portofolio', $_SESSION['login_mahasiswa']);

                    foreach ($ambilPortofolioId as $data) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $data->keterangan; ?></td>
                            <td><img src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $data->photo; ?>" class="img-fluid" alt="Alumni 1" style="width:100px; object-fit: cover;"></td>
                            <td>
                                <a class="btn btn-danger mb-1 text-decoration-none" href="crud/?id_portofolio=<?= $data->id_portofolio ?>"><i class="fa fa-trash"></i> Hapus</a>
                                <button data-toggle="modal" data-target="#editModal<?= $data->id_portofolio ?>" class="btn btn-primary">Edit</button>
                            </td>
                        </tr>
                        <!-- Modal Form Edit -->
                        <div class="modal fade" id="editModal<?= $data->id_portofolio ?>" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="tambahModalLabel">Edit Data Portofolio</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group row">
                                                <label class="col-2 col-form-label">Deskripsi</label>
                                                <input type="hidden" name="id_portofolio" value="<?= $data->id_portofolio ?>">
                                                <input class="col-9 form-control" type="text" name="deskripsi" value="<?= $data->keterangan ?>">
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-2 col-form-label">File Photo</label>
                                                <input type="hidden" name="photo_post" value="<?= $data->photo ?>">
                                                <input class="col-9 form-control" type="file" name="photo" placeholder="Pilih Photo">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Tab Profil -->
        <div class="tab-pane fade" id="profil" role="tabpanel" aria-labelledby="profil-tab">
            <!-- Konten untuk Manajemen Profil -->
            <h5>Manajemen Profil</h5>
            <?php

            $mahasiswa = ambilMahasiswaId('mahasiswa', $_SESSION['login_mahasiswa']);

            ?>
            <!-- Form untuk mengedit profil atau lainnya -->
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <label for="nama_mahasiswa">Nama:</label>
                            <input type="hidden" name="editprofil" value="<?= $_SESSION['login_mahasiswa'] ?>">
                            <input type="text" class="form-control" id="nama_mahasiswa" name="nama_mahasiswa" value="<?= $mahasiswa->nama_mahasiswa ?>">
                        </div>
                        <div class="form-group">
                            <label for="bio">bio:</label>
                            <input type="text" class="form-control" id="bio" name="bio" value="<?= $mahasiswa->bio ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Rate Harga:</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?= $mahasiswa->email ?>">
                        </div>
                        <div class="form-group">
                            <label for="pasphoto">Photo Profil</label>
                            <input type="file" class="form-control" id="pasphoto" name="pasphoto" placeholder="Ubah Profil">
                            <input type="hidden" class="form-control" id="pasphoto" name="pasphoto_post" value="<?= $mahasiswa->pasphoto ?>">
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                    <img src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $mahasiswa->pasphoto; ?>" class="img-fluid mb-2" alt="Alumni Photo" style="object-fit: cover;">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Ubah Profil</button>
                <a href="https://digiumkm.com/portofolio//umkm/?hapus=<?= $_SESSION['login_mahasiswa'] ?>" class="btn btn-danger text-decoration-none">Hapus Akun</a>
            </form>
        </div>
    </div>
</div>