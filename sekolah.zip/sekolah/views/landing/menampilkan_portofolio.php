<div class="container-fluid pt-4">
    
    <?php
    $no = 1;
    $mengambil_freelance = ambilMahasiswaId('mahasiswa', $_GET['id_mahasiswa']);
    ?>

    <div class="row mb-4" style="background-color: rgba(220, 220, 220, 0.7); padding: 20px; border-radius: 10px;">
        <div class="col-md-4">
            <img src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $mengambil_freelance->pasphoto; ?>" class="img-fluid rounded-circle" alt="Alumni Photo" style="height: 400px; object-fit: cover;">
        </div>
        <div class="col-md-6 d-flex flex-column justify-content-center">
            <h4 class="mb-2"><?= $mengambil_freelance->nama_mahasiswa ?></h4>
            <p class="text-muted"><?= $mengambil_freelance->bio ?></p>
            <a href="https://wa.me/6285172414024?text=halo%20saya%20ingin%20memesan%20:%0Amahasiswa%20:%20<?= $mengambil_freelance->nama_mahasiswa ?>%0Ajasa%20:%20<?= $mengambil_freelance->kategori ?>%0Aapakah%20bisa%20dibantu?" target="_blank" class="btn btn-primary mt-2 card-text text-decoration-none"><strong>Contact via WhatsApp</strong></a>
        </div>
    </div>

    <h5 class="mb-3">Portfolio</h5>
    <div class="row" style="background-color: rgba(255, 255, 255, 0.9); padding: 20px; border-radius: 10px;">
        <?php
        $mengambil_portofolio = ambilPortofolioId('portofolio', $_GET['id_mahasiswa']);
        foreach ($mengambil_portofolio as $dataportofolio) {
        ?>
            <div class="col-12 col-sm-6 col-md-4 mb-4">
                <div class="card alumni-card text-center">
                    <img src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $dataportofolio->photo; ?>" class="card-img-top img-fluid" alt="Portfolio Image" style=" object-fit: cover;">
                    <div class="card-body">
                        <p class="card-text">Deskripsi: <?= $dataportofolio->keterangan; ?></p>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>