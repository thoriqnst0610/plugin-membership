<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<div class="container-fluid d-flex align-items-center justify-content-center" style="min-height: 80vh; background-color: #f8f9fa;">
    <div class="row w-100">
        <div class="col-12 col-md-5 mx-auto">
            <div class="card p-4 shadow-sm">
                <h3 class="text-center mb-4">Daftar User Baru</h3>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="nama_user" class="form-label">Nama</label>
                        <input type="hidden" name="aksi" value="daftaruser">
                        <input type="text" class="form-control" name="nama_user" id="nama_user" required>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <input type="text" class="form-control" name="alamat" id="alamat" required>
                    </div>
                    <div class="mb-3">
                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                        <select id="jenis_kelamin" name="jenis_kelamin" class="form-control" required>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="telepon" class="form-label">Telepon</label>
                        <input type="text" class="form-control" name="telepon" id="telepon" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" id="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Daftar Sekarang</button>
                </form>
                <div class="mt-3 text-center">
                    Sudah punya akun? <a href="user/">Login sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>
