<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<div class="container-fluid d-flex align-items-center justify-content-center" style="min-height: 100vh; background-color: #f8f9fa;">
    <div class="row w-100">
        <div class="col-12 col-md-5 mx-auto">
        <h3><strong><?php if (isset($_GET['pesan'])) { echo $_GET['pesan']; } ?></strong></h3>
            <div class="card p-4 shadow-sm">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-1">
                        <label for="nama_mahasiswa" class="form-label">Nama</label>
                        <input type="hidden" name="daftardong" value="haha">
                        <input type="text" class="form-control" name="nama_mahasiswa" id="nama_mahasiswa" required>
                    </div>
                    <div class="mb-1">
                        <label for="alamat_mahasiswa" class="form-label">Alamat</label>
                        <input type="text" class="form-control" name="alamat_mahasiswa" id="alamat_mahasiswa" required>
                    </div>
                    <div class="mb-1">
                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                        <select id="jenis_kelamin" name="jenis_kelamin" class="form-control" required>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-1">
                        <label for="telepon" class="form-label">Telepon</label>
                        <input type="text" class="form-control" name="telepon" id="telepon" required>
                    </div>
                    <div class="mb-1">
                        <label for="harga" class="form-label">Rate Harga</label>
                        <input type="text" class="form-control" name="harga" id="harga" required>
                    </div>
                    <div class="mb-1">
                        <label for="pasphoto" class="form-label">Photo Profil</label>
                        <input type="file" class="form-control" name="pasphoto" id="pasphoto" accept="image/*" required>
                    </div>
                    <div class="mb-1">
                        <label for="kategori" class="form-label">Kategori Keahlian</label>
                        <select id="kategori" name="kategori" class="form-control" required>
                            <option value="Fotografi Produk">Fotografi Produk</option>
                            <option value="Desain Grafis">Desain Grafis</option>
                            <option value="Pembuatan Kontent Video">Pembuatan Kontent Video</option>
                            <option value="Pembuatan Kontent Social Media">Pembuatan Kontent Social Media</option>
                            <option value="Pembuatan Website">Pembuatan Website</option>
                        </select>
                    </div>
                    <div class="mb-1">
                        <label for="bio" class="form-label">Bio</label>
                        <input type="text" class="form-control" name="bio" id="bio" required>
                    </div>
                    <div class="mb-1">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" id="username" required>
                    </div>
                    <div class="mb-1">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Daftar Sekarang</button>
                </form>
                <div class="mt-3 text-center">
                    Sudah punya akun? <a href="freelance/">Login sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Include Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">