<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<div class="container-fluid d-flex align-items-center justify-content-center" style="min-height: 80vh; padding-top: 20px; background-color: #f8f9fa;">
    <div class="row w-100">
        <div class="col-12 col-md-5 mx-auto">
            <div class="card p-4 shadow-sm">
                <h3 class="text-center mb-4">Login User</h3>
                <h3><strong><?php if (isset($pesan)) { echo $pesan; } ?></strong></h3>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="hidden" name="aksi" value="loginuser">
                        <input type="text" class="form-control" name="username" id="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Sign Sekarang</button>
                </form>
                <div class="mt-3 text-center">
                    Belum punya akun? <a href="user/?aksi=daftaruser">Daftar sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>
