<div class="container-fluid pt-4">
    <!-- ed -->
    <div class="row">
        <?php
        $mengambil_freelance = ambilMahasiswa('mahasiswa');
        foreach ($mengambil_freelance as $data) { ?>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                <a href="portofolio/?id_mahasiswa=<?= $data->id_mahasiswa ?>" class="text-dark text-decoration-none">
                    <div class="card alumni-card text-center shadow-sm border-0">
                        <img src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $data->pasphoto; ?>" class="card-img-top img-fluid" alt="<?= $data->nama_mahasiswa; ?>" style="height: 350px; object-fit: cover;">
                        <div class="card-body">
                            <h3 class="card-title"><?= $data->nama_mahasiswa; ?></h3>
                            <p class="card-text"><strong>Keahlian:</strong> <?= $data->kategori; ?></p>
                            <p class="card-text"><strong>Rate Harga:</strong> <?= $data->	email; ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php } ?>
    </div>
</div>